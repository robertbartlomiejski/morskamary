# morskamary — live cumulative scientific package

**Version tag**: 30090903921-1
**Generated**: 2026-07-24T11:52:38+00:00

## Contents

- `RELEASE_MANIFEST.json` — package manifest with checksums and provenance metadata.
- `CHECKSUMS.sha256` — one line per file with its SHA-256 digest.
- `CITATION_APA.txt` — APA-style citation template.
- `VARIABLE_LABELS.csv`, `VALUE_LABELS.csv` — statistical software value/variable dictionaries.
- `data/csv/` — deterministic CSV tables (evidence, signals, derived demands, gap model, credentials, outcomes, novelty).
- `data/jsonl/` — canonical JSONL audit records and evidence-bound hypothesis fragments.
- `protocol/` — authoritative protocol, executable projection, and declared acquisition constraints.
- `provenance/` — query execution log and Layer 1 raw acquisition index for the packaged run.
- `statistics/` — Layer 4 cross-tables, matrices, multivariate results, and taxonomic clusters.
- `data/sqlite/` — portable SQLite database (may be skipped; see `RELEASE_MANIFEST.json`).
- `reports/` — HTML statistical report, methodological audit, and PDF (may be a text stub if PDF rendering is unavailable).

## Demand-strength formula

    demand_strength_score = 0.30*normalized_unique_doi_count + 0.20*provider_diversity_score + 0.20*temporal_recency_score + 0.15*query_diversity_score + 0.15*semantic_confidence_mean

## Reliability rule

Records with `record_novelty_status = duplicate_only` are excluded from statistical growth metrics. Growth indexes are recalculated only on `new_record`, `updated_metadata`, `provider_enriched`, and `semantic_enriched` records.
